#!/bin/bash

kubectl logs -l app=backend-selector
