docker build -t backend:v1.0.0 .
scripts/restart-app-pod.sh

