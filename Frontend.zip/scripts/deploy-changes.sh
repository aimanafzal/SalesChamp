docker build -t frontend:v1.0.0 .
scripts/restart-app-pod.sh

