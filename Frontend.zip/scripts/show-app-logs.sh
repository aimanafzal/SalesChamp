#!/bin/bash

kubectl logs -l app=frontend-selector
